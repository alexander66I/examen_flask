from flask import Flask, render_template, request

app = Flask(__name__)

PRECIO_TARRO = 9000
DESCUENTOS = {
    "joven": 0.15,  # 18-30 años
    "adulto": 0.25,  # >30 años
    "menor": 0.0  # <18 años
}

USUARIOS = {
    "juan": "admin",
    "pepe": "user"
}


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/ejercicio1', methods=['GET', 'POST'])
def ejercicio1():
    if request.method == 'POST':
        nombre = request.form['nombre'].strip()
        edad = int(request.form['edad'])
        tarros = int(request.form['tarros'])

        total_sin_descuento = tarros * PRECIO_TARRO

        if edad < 18:
            tipo_descuento = "menor"
        elif 18 <= edad <= 30:
            tipo_descuento = "joven"
        else:
            tipo_descuento = "adulto"

        descuento = DESCUENTOS[tipo_descuento]
        total_con_descuento = total_sin_descuento * (1 - descuento)

        mensaje_descuento = f"Descuento aplicado: {descuento * 100}%" if descuento > 0 else "Sin descuento aplicable"

        return render_template('resultado1.html',
                               nombre=nombre,
                               tarros=tarros,
                               total_sin_descuento=f"${total_sin_descuento:,.0f}",
                               total_con_descuento=f"${total_con_descuento:,.0f}",
                               mensaje_descuento=mensaje_descuento)

    return render_template('ejercicio1.html')


@app.route('/ejercicio2', methods=['GET', 'POST'])
def ejercicio2():
    mensaje_error = ""

    if request.method == 'POST':
        usuario = request.form['usuario'].strip()
        contrasena = request.form['contrasena']

        if usuario in USUARIOS and USUARIOS[usuario] == contrasena:
            mensaje = f"Bienvenido administrador {usuario}" if usuario == "juan" else f"Bienvenido usuario {usuario}"
            return render_template('resultado2.html', mensaje=mensaje)
        else:
            mensaje_error = "Usuario o contraseña incorrectos"

    return render_template('ejercicio2.html', mensaje_error=mensaje_error)


if __name__ == '__main__':
    app.run(debug=True, port=5000)